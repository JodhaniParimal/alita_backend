const EMPLOYEE_SKILL_MESSAGE = {
    EMPLOYEE_SKILL_EXIST : "Employee skill alreadyexist",
    EMPLOYEE_SKILL_ADDED : "Employee skill added successfully.",
    EMPLOYEE_SKILL_NOT_ADDED : "Issue adding employee skill",

    EMPLOYEE_SKILL_FOUND : "Employee skill found successfully",
    EMPLOYEE_SKILL_NOT_FOUND : "Employee skill not found"
}

module.exports = { EMPLOYEE_SKILL_MESSAGE }