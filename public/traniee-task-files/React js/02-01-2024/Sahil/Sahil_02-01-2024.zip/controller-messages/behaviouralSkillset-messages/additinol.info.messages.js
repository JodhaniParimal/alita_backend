const EMPLOYEE_INFO_MESSAGE = {
    EMPLOYEE_INFO_ADDED : "Employee additional information added successfully.",
    EMPLOYEE_INFO_NOT_ADDED : "Issue adding employee additional information",
    
    EMPLOYEE_INFO_FOUND : "Employee additional information found successfully.",
    EMPLOYEE_INFO_NOT_FOUND : "Employee additional information not found.",

}

module.exports = { EMPLOYEE_INFO_MESSAGE }