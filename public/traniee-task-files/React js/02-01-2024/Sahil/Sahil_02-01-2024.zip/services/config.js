module.exports = {
    attachment: {
        path: "attachment"
    }
}