module.exports = {
  DEFAULT_DEPARTMENT: "IT Admin",
  DEFAULT_ROLE: "admin",
};
