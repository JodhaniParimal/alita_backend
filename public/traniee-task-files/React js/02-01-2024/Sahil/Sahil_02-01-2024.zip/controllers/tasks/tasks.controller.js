const moment = require("moment");
const momentTimezone = require("moment-timezone");
const path = require("path");
const fs = require("fs");
const cron = require("node-cron");

const {
  RESPONSE_PAYLOAD_STATUS_SUCCESS,
  RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR,
  RESPONSE_STATUS_CODE_OK,
  RESPONSE_PAYLOAD_STATUS_ERROR,
  RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
  AUTH_USER_DETAILS,
} = require("../../constants/global.constants");
const {
  TASK_COMMENTS,
  EMPLOYEE,
  PROJECT,
  LEAD,
} = require("../../constants/models.enum.constants");
const {
  TASK_MESSAGE,
} = require("../../controller-messages/tasks-messages/tasks.messages");
const { Tasks } = require("../../models/tasks/tasks.model");
const { ENUMS } = require("../../constants/enum.constants");
const Employee = require("../../models/employee/employee.model");
const { ObjectId } = require("mongodb");
const XLSX = require("xlsx");
const { checkColumn } = require("../../helpers/fn");
const { Project } = require("../../models/project/project.model");
const {
  changeTaskStatusMailer,
} = require("../../services/mailer/changeTaskStatusMailTemplate");
const { Cron_Job_Logs } = require("../../models/logs/cronjob.logs.model");
const {
  Employee_Project,
} = require("../../models/project/employee.project.model");
const { dateAndTimeFormat } = require("../../helpers/date-formatter");
const { default: mongoose } = require("mongoose");
const Team_managment = require("../../models/team_managment/team.managment.model");
const {
  TEAM_MESSAGE,
} = require("../../controller-messages/teammanagment-messages/team.managment.messages");
const { Task_Comments } = require("../../models/tasks/task.comments.model");

/* LIST ALL TASKS of Employee by employee_code // METHOD: POST // PAYLOAD: employee_code, project_code */
const listAllTasks = async (req, res) => {
  try {
    const {
      filter,
      task_status,
      employee_code,
      search,
      sort,
      current_page,
      per_page,
    } = req.body;

    const current_page_f = current_page ? current_page : 1;
    const per_page_f = per_page ? per_page : 25;

    const sort_column = sort
      ? sort.column
        ? sort.column
        : "project_code"
      : "project_code";

    const order_by = sort.order ? sort.order : -1;

    const search_by = search ? search.replace(/[^a-zA-Z0-9 ]/g, "") : "";

    const d = new Date();

    const date_start = filter
      ? filter.date
        ? filter.date.start
          ? filter.date.start
          : new Date(d.setHours(d.getHours() - d.getHours()))
        : new Date(d.setHours(d.getHours() - d.getHours()))
      : null;
    const date_end = filter
      ? filter.date
        ? filter.date.end
          ? filter.date.end
          : new Date(d.setDate(d.getDate() + 1))
        : new Date(d.setDate(d.getDate() + 1))
      : null;

    const { teamMembers } = req[AUTH_USER_DETAILS];

    let matchObj = {
      $or: [
        {
          created_date: {
            $gte: new Date(date_start),
            $lte: new Date(date_end),
          },
        },
        {
          assigned_on: {
            $gte: new Date(date_start),
            $lte: new Date(date_end),
          },
        },
      ],
      employee_code: { $in: teamMembers },
      is_deleted: false,
      is_disabled: false,
    };

    if (task_status) {
      matchObj = {
        ...matchObj,
        status: task_status,
      };
    }

    if (employee_code) {
      matchObj = {
        ...matchObj,
        employee_code: employee_code,
      };
    }

    if (search_by) {
      matchObj = {
        ...matchObj,
        $or: [
          {
            title: { $regex: search_by, $options: "i" },
          },
          {
            project_code: { $regex: search_by, $options: "i" },
          },
          {
            employee_code: { $regex: search_by, $options: "i" },
          },
          {
            status: { $regex: search_by, $options: "i" },
          },
        ],
      };
    }

    let result = await Tasks.aggregate([
      {
        $match: matchObj,
      },
      {
        $lookup: {
          from: EMPLOYEE,
          let: { e_code: "$employee_code" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$employee_code", "$$e_code"] },
                is_deleted: false,
              },
            },
            {
              $project: {
                _id: 0,
                fullname: { $concat: ["$firstname", " ", "$lastname"] },
                email: 1,
                profile_pic: {
                  $ifNull: ["$profile_pic", "-"],
                },
              },
            },
          ],
          as: "employee_details",
        },
      },
      {
        $unwind: "$employee_details",
      },
      {
        $lookup: {
          from: PROJECT,
          let: { p_code: "$project_code" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$project_code", "$$p_code"] },
                is_deleted: false,
              },
            },
            {
              $project: {
                _id: 0,
                project_title: 1,
              },
            },
          ],
          as: "projects",
        },
      },
      {
        $unwind: "$projects",
      },
      {
        $addFields: {
          project_title: "$projects.project_title",
        },
      },
      {
        $unset: "projects",
      },
      {
        $lookup: {
          from: TASK_COMMENTS,
          let: { id: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$task_id", "$$id"] },
                is_deleted: false,
                is_disabled: false,
              },
            },
            {
              $lookup: {
                from: EMPLOYEE,
                let: { e_code: "$commented_by" },
                pipeline: [
                  {
                    $match: {
                      $expr: { $eq: ["$employee_code", "$$e_code"] },
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      name: { $concat: ["$firstname", "-", "$lastname"] },
                      employee_code: 1,
                    },
                  },
                ],
                as: "commented_by",
              },
            },
            {
              $addFields: {
                commented_by: {
                  $cond: {
                    if: { $gt: [{ $size: "$commented_by" }, 0] },
                    then: { $arrayElemAt: ["$commented_by", 0] },
                    else: "---",
                  },
                },
              },
            },
            {
              $project: {
                _id: 1,
                comment: 1,
                commented_by: {
                  $ifNull: ["$commented_by.employee_code", "---"],
                },
                name: { $ifNull: ["$commented_by.name", "---"] },
                created_date: 1,
              },
            },
          ],
          as: "comments",
        },
      },
      {
        $sort: { lead_code: 1, with_tracker: -1 },
      },
      {
        $project: {
          is_deleted: 0,
          is_disabled: 0,
          updated_by: 0,
          deleted_by: 0,
        },
      },
      {
        $facet: {
          metadata: [{ $count: "total" }],
          data: [
            { $skip: (current_page_f - 1) * per_page_f },
            { $limit: per_page_f },
            { $sort: { [sort_column]: order_by } },
          ],
        },
      },
      {
        $addFields: {
          total: { $arrayElemAt: ["$metadata.total", 0] },
          current_page: current_page_f,
          per_page: per_page_f,
        },
      },
      {
        $project: {
          data: 1,
          metaData: {
            per_page: "$per_page",
            total_page: { $ceil: { $divide: ["$total", per_page_f] } },
            current_page: "$current_page",
            total_count: "$total",
          },
        },
      },
    ]);
    if (result.data && result.data.length) {
      result = result.data.map((task) => {
        task.due_date = dateAndTimeFormat(task.due_date, "Asia/Kolkata");
        task.assigned_on = dateAndTimeFormat(task.assigned_on, "Asia/Kolkata");
        return task;
      });
    }
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
      message: TASK_MESSAGE.TASK_FOUND,
      data: result[0],
      error: null,
    };
    return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* LIST ALL TASKS details of Employee// METHOD: POST // PAYLOAD: employee_code, project_code */
const allEmployeeTaskInfotracker = async (req, res) => {
  try {
    const filter = req.body.filter;
    const d = new Date();

    // let start_date = new Date(d.setHours(d.getHours() - d.getHours()));
    // let end_date = new Date(d.setDate(d.getDate() + 1));

    let start_date = new Date(
      d.getFullYear(),
      d.getMonth(),
      d.getDate(),
      5,
      30,
      0,
      0
    );
    let end_date = new Date(
      d.getFullYear(),
      d.getMonth(),
      d.getDate() + 1,
      5,
      29,
      0,
      0
    );

    const { teamMembers } = req[AUTH_USER_DETAILS];

    if (filter && filter.date) {
      const { start, end } = filter.date;
      if (start) {
        start_date = new Date(start);
      }
      if (end) {
        end_date = new Date(end);
      }
    }

    let matchObj = {
      $or: [
        {
          created_date: {
            $gte: new Date(start_date),
            $lte: new Date(end_date),
          },
        },
      ],
      employee_code: { $in: teamMembers },
      is_deleted: false,
      is_disabled: false,
    };

    let matchObj1 = {
      is_deleted: false,
      employee_code: { $in: teamMembers },
    };

    let result = await Tasks.aggregate([
      {
        $match: matchObj,
      },
      {
        $lookup: {
          from: EMPLOYEE,
          let: { e_code: "$employee_code" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$employee_code", "$$e_code"] },
                is_deleted: false,
              },
            },
            {
              $project: {
                _id: 0,
                employee_code: 1,
                fullname: { $concat: ["$firstname", " ", "$lastname"] },
              },
            },
          ],
          as: "employee_details",
        },
      },
      {
        $unwind: "$employee_details",
      },
      {
        $project: {
          status_history: 0,
          is_deleted: 0,
          is_disabled: 0,
          created_by: 0,
          description: 0,
          updated_by: 0,
          deleted_by: 0,
        },
      },
    ]);

    let allEmployee = await Employee.aggregate([
      {
        $match: matchObj1,
      },
      {
        $project: {
          _id: 1,
          employee_code: 1,
          name: { $concat: ["$firstname", " ", "$lastname"] },
        },
      },
    ]);

    const employeesWithTask = [];
    const employeesWithoutTask = [];

    allEmployee.forEach((employee) => {
      const employeeCode = employee.employee_code;

      const matchingTask = result.find(
        (task) => task.employee_details.employee_code === employeeCode
      );

      if (matchingTask) {
        employeesWithTask.push(employee);
      } else {
        employeesWithoutTask.push(employee);
      }
    });

    const withTracker = [];
    const withoutTracker = [];

    for (const item of result) {
      if (item.with_tracker) {
        withTracker.push(item);
      } else {
        withoutTracker.push(item);
      }
    }

    function calculateSum(dataArray) {
      let sumExpected = 0;
      let sumReal = 0;

      dataArray.forEach((item) => {
        sumExpected += parseFloat(item.expected_tracker_time);
        sumReal += parseFloat(item.real_tracker_time);
      });
      return { sumExpected, sumReal };
    }

    const withTrackerSum = calculateSum(withTracker);
    const withoutTrackerSum = calculateSum(withoutTracker);

    const output = {
      expected_hour_with_tracker: withTrackerSum.sumExpected,
      expected_hour_without_tracker: withoutTrackerSum.sumExpected,
      covered_hour_with_tracker: withTrackerSum.sumReal,
      covered_hour_without_tracker: withoutTrackerSum.sumReal,
      employee_with_task: employeesWithTask,
      employee_without_task: employeesWithoutTask,
    };

    if (output) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_FOUND,
        data: output,
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_NOT_FOUND,
        data: {},
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* LIST ALL TASKS of Employee by employee_code // METHOD: POST // PAYLOAD: employee_code, project_code */
const listTasks = async (req, res) => {
  try {
    const { employee_code, project_code, task_status } = req.body;
    let whereCond = {
      is_deleted: false,
      is_disabled: false,
      employee_code: employee_code,
    };
    if (project_code) {
      whereCond = { ...whereCond, project_code: { $in: project_code } };
      // whereCond = { ...whereCond, project_code: project_code };
    }
    if (task_status === ENUMS.TASK_STATUS.TODO) {
      whereCond.status = ENUMS.TASK_STATUS.TODO;
    } else if (task_status === ENUMS.TASK_STATUS.IN_PROGRESS) {
      whereCond.status = ENUMS.TASK_STATUS.IN_PROGRESS;
    } else if (task_status === ENUMS.TASK_STATUS.READY_TO_QA) {
      whereCond.status = ENUMS.TASK_STATUS.READY_TO_QA;
    } else if (task_status === ENUMS.TASK_STATUS.DONE) {
      whereCond.status = ENUMS.TASK_STATUS.DONE;
    }
    let result = await Tasks.aggregate([
      {
        $match: whereCond,
      },
      {
        $lookup: {
          from: EMPLOYEE,
          let: { e_code: "$employee_code" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$employee_code", "$$e_code"] },
                is_deleted: false,
              },
            },
            {
              $project: {
                _id: 0,
                fullname: { $concat: ["$firstname", " ", "$lastname"] },
                email: 1,
                profile_pic: {
                  $ifNull: ["$profile_pic", "-"],
                },
              },
            },
          ],
          as: "employee_details",
        },
      },
      {
        $unwind: "$employee_details",
      },
      {
        $lookup: {
          from: PROJECT,
          let: { p_code: "$project_code" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$project_code", "$$p_code"] },
                is_deleted: false,
              },
            },
            {
              $project: {
                _id: 0,
                project_title: 1,
              },
            },
          ],
          as: "projects",
        },
      },
      {
        $unwind: "$projects",
      },
      {
        $addFields: {
          project_title: "$projects.project_title",
        },
      },
      {
        $unset: "projects",
      },
      {
        $lookup: {
          from: TASK_COMMENTS,
          let: { id: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$task_id", "$$id"] },
                is_deleted: false,
                is_disabled: false,
              },
            },
            {
              $project: {
                _id: 1,
                comment: 1,
                commented_by: 1,
                name: 1,
              },
            },
          ],
          as: "comments",
        },
      },
      {
        $project: {
          is_deleted: 0,
          is_disabled: 0,
          updated_by: 0,
          deleted_by: 0,
        },
      },
      {
        $sort: { assigned_on: 1 },
      },
    ]);

    result = result.map((task) => {
      task.due_date = dateAndTimeFormat(task.due_date, "Asia/Kolkata");

      task.assigned_on = dateAndTimeFormat(task.assigned_on, "Asia/Kolkata");

      return task;
    });

    if (result && result.length > 0) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_FOUND,
        data: result,
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_NOT_FOUND,
        data: [],
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    console.log("error", error);
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* LIST TASKS Hours by employee_code// METHOD: GET*/
const listTaskHour = async (req, res) => {
  try {
    // const filter = req.body.filter;
    const d = new Date();
    const { employee_code } = req.body;

    let start_date = new Date(
      d.getFullYear(),
      d.getMonth(),
      d.getDate(),
      5,
      30,
      0,
      0
    );
    let end_date = new Date(
      d.getFullYear(),
      d.getMonth(),
      d.getDate() + 1,
      5,
      29,
      0,
      0
    );

    const document = await Tasks.aggregate([
      {
        $match: {
          employee_code: employee_code,
          created_date: {
            $gte: new Date(start_date),
            $lte: new Date(end_date),
          },
          is_deleted: false,
        },
      },
      {
        $group: {
          _id: null,
          totalExpectedTrackerTime: {
            $sum: { $toDouble: "$expected_tracker_time" },
          },
        },
      },
      {
        $project: {
          _id: 0,
          totalExpectedTrackerTime: {
            $round: ["$totalExpectedTrackerTime", 2],
          },
        },
      },
    ]);
    const totalExpectedTrackerTime =
      document.length > 0 ? document[0].totalExpectedTrackerTime : 0;

    let remainingTrackerTime = (8.3 - totalExpectedTrackerTime).toFixed(2);

    if (totalExpectedTrackerTime > 8.3) {
      remainingTrackerTime = "0.00";
    }

    if (document) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.REMAINING_TASK_HOUR_FOUND,
        data: remainingTrackerTime,
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.REMAINING_TASK_HOUR_NOT_FOUND,
        data: {},
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* LIST TASKS By Id in PARAMS // METHOD: GET // PARAMS: task_id */
const listTasksById = async (req, res) => {
  try {
    const { id } = req.params;
    const match_id = new mongoose.Types.ObjectId(id);
    // const match_id = new ObjectId(id);
    let result = await Tasks.aggregate([
      {
        $match: {
          is_deleted: false,
          is_disabled: false,
          _id: match_id,
        },
      },
      {
        $unwind: {
          path: "$status_history",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: EMPLOYEE,
          let: { e_code: "$status_history.updated_by" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$employee_code", "$$e_code"] },
                is_deleted: false,
              },
            },
            {
              $project: {
                updated_by: { $concat: ["$firstname", " ", "$lastname"] },
              },
            },
          ],
          as: "status_history.updated_by",
        },
      },
      {
        $unwind: {
          path: "$status_history.updated_by",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $set: {
          "status_history.updated_by": "$status_history.updated_by.updated_by",
        },
      },
      {
        $group: {
          _id: "$_id",
          title: { $first: "$title" },
          real_tracker_time: { $first: "$real_tracker_time" },
          expected_tracker_time: { $first: "$expected_tracker_time" },
          project_code: { $first: "$project_code" },
          employee_code: { $first: "$employee_code" },
          description: { $first: "$description" },
          status: { $first: "$status" },
          client_time: { $first: "$client_time" },
          with_tracker: { $first: "$with_tracker" },
          due_date: { $first: "$due_date" },
          assigned_on: { $first: "$assigned_on" },
          created_by: { $first: "$created_by" },
          created_date: { $first: "$created_date" },
          status_history: {
            $push: "$status_history",
          },
        },
      },
      {
        $lookup: {
          from: EMPLOYEE,
          let: { e_code: "$employee_code" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$employee_code", "$$e_code"] },
                is_deleted: false,
              },
            },
            {
              $project: {
                _id: 0,
                fullname: { $concat: ["$firstname", " ", "$lastname"] },
                email: 1,
                profile_pic: {
                  $ifNull: ["$profile_pic", "-"],
                },
              },
            },
          ],
          as: "employee_details",
        },
      },
      {
        $unwind: "$employee_details",
      },
      {
        $lookup: {
          from: PROJECT,
          let: { p_code: "$project_code" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$project_code", "$$p_code"] },
                is_deleted: false,
              },
            },
            {
              $project: {
                _id: 0,
                project_title: 1,
              },
            },
          ],
          as: "projects",
        },
      },
      {
        $unwind: "$projects",
      },
      {
        $addFields: {
          project_title: "$projects.project_title",
        },
      },
      {
        $unset: "projects",
      },
      {
        $lookup: {
          from: TASK_COMMENTS,
          let: { id: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$task_id", "$$id"] },
                is_deleted: false,
                is_disabled: false,
              },
            },
            {
              $lookup: {
                from: EMPLOYEE,
                let: { e_code: "$commented_by" },
                pipeline: [
                  {
                    $match: {
                      $expr: { $eq: ["$employee_code", "$$e_code"] },
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      name: { $concat: ["$firstname", "-", "$lastname"] },
                      employee_code: 1,
                    },
                  },
                ],
                as: "commented_by",
              },
            },
            {
              $addFields: {
                commented_by: {
                  $cond: {
                    if: { $gt: [{ $size: "$commented_by" }, 0] },
                    then: { $arrayElemAt: ["$commented_by", 0] },
                    else: "---",
                  },
                },
              },
            },
            {
              $project: {
                _id: 1,
                comment: 1,
                commented_by: {
                  $ifNull: ["$commented_by.employee_code", "---"],
                },
                name: { $ifNull: ["$commented_by.name", "---"] },
                created_date: 1,
              },
            },
          ],
          as: "comments",
        },
      },
      {
        $project: {
          is_deleted: 0,
          is_disabled: 0,
          updated_by: 0,
          deleted_by: 0,
        },
      },
    ]);

    if (result && result.length > 0) {
      result[0].comments.map((e) => (e.updated_date = e.created_date));

      result[0]["activity"] = [].concat(
        Object.keys(result[0].status_history[0]).length === 0
          ? []
          : result[0].status_history,
        result[0].comments.length ? result[0].comments : []
      );

      delete result[0].status_history, delete result[0].comments;

      if (result[0].activity.length) {
        result[0].activity.sort((a, b) => b.updated_date - a.updated_date);
      }

      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_FOUND,
        data: result[0],
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_NOT_FOUND,
        data: {},
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* ADD NEW TASK // METHOD: POST */
/* PAYLOAD: title, project_code, employee_code, client_time, with_tracker, due_date, assigned_on, description */
const addTask = async (req, res) => {
  try {
    const {
      title,
      description = "",
      project_code,
      employee_code,
      expected_tracker_time,
      real_tracker_time,
      client_time,
      with_tracker,
      due_date,
      assigned_on,
      status,
      newComments,
    } = req.body;
    const { employee_code: auth_employee_code } = req[AUTH_USER_DETAILS];

    const todayIST = moment().tz("Asia/Kolkata").endOf("day");

    const formattedDueDate = due_date
      ? momentTimezone.tz(new Date(due_date), "Asia/Kolkata").format()
      : todayIST.format();
    const formattedAssignDate = assigned_on
      ? momentTimezone.tz(new Date(assigned_on), "Asia/Kolkata").format()
      : moment().format();

    let createObj = {
      title: title,
      description: description,
      project_code: project_code,
      employee_code: employee_code,
      client_time: client_time,
      with_tracker: with_tracker,
      expected_tracker_time: expected_tracker_time,
      due_date: formattedDueDate,
      assigned_on: formattedAssignDate,
      real_tracker_time: real_tracker_time,
      created_by: auth_employee_code,
      created_date: moment().format(),
      status_history: [
        {
          status_from: null,
          status_to: ENUMS.TASK_STATUS.TODO,
          updated_by: auth_employee_code,
          updated_date: moment().format(),
        },
      ],
    };

    if (status) {
      createObj = { ...createObj, status: status };
    }
    var result = await Tasks.create(createObj);
    if (result) {
      result = {
        ...result._doc,
        due_date: dateAndTimeFormat(result._doc.due_date, "Asia/Kolkata"),
        assigned_on: dateAndTimeFormat(result._doc.assigned_on, "Asia/Kolkata"),
      };
    }
    if (newComments != undefined) {
      const task_id = result._id;

      const cmnt = newComments.map((o) => {
        return {
          ...o,
          task_id: task_id,
        };
      });

      let result1 = await Task_Comments.insertMany(cmnt);
      result = {
        ...result,
        comments: result1,
      };
    }
    if (result) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_SAVED,
        data: result,
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: {},
        error: TASK_MESSAGE.TASK_NOT_SAVED,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* ADD NEW TASKs BY EXCEL FILE // METHOD: POST */
/* PAYLOAD: title, project_code, employee_code, client_time, with_tracker, due_date, assigned_on, description */
const addTaskByExcelFile = async (req, res) => {
  try {
    const { employee_code: auth_employee_code } = req[AUTH_USER_DETAILS];

    if (!req.file) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: null,
        error: TASK_MESSAGE.EXCEL_FILE_NOT_EXISTS,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }

    var worksheetColumns = [
      "title",
      "description",
      "project_code",
      "employee_code",
      "client_time",
      "with_tracker",
      "due_date",
      "assigned_on",
    ];

    let path = req.file.path;
    var workbook = XLSX.readFile(path);
    var sheet_name_list = workbook.SheetNames;
    let jsonData = XLSX.utils.sheet_to_json(
      workbook.Sheets[sheet_name_list[0]],
      { raw: false }
    );
    const header = [];
    const columnCount =
      XLSX.utils.decode_range(workbook.Sheets[sheet_name_list[0]]["!ref"]).e.c +
      1;
    for (let i = 0; i < columnCount; ++i) {
      header[i] =
        workbook.Sheets[sheet_name_list[0]][`${XLSX.utils.encode_col(i)}1`].v;
    }

    if (!(header.sort().join(",") === worksheetColumns.sort().join(","))) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: null,
        error: TASK_MESSAGE.EXCEL_FILE_INVALID,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
    if (jsonData.length === 0) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: null,
        error: TASK_MESSAGE.EXCEL_FILE_EMPTY,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }

    let failedTasks = { count: 0, data: [] },
      successTasks = { count: 0, data: [] };

    for (let i = 0; i < jsonData.length; i++) {
      jsonData[i].due_date = jsonData[i].due_date
        ? moment(new Date(jsonData[i].due_date)).format()
        : moment(new Date()).set({ hour: 23, minute: 59, second: 59 }).format();
      jsonData[i].assigned_on = jsonData[i].assigned_on
        ? moment(new Date(jsonData[i].assigned_on)).format()
        : moment(new Date()).format();

      if (
        jsonData[i].title == undefined ||
        jsonData[i].title == "" ||
        jsonData[i].title == null ||
        jsonData[i].project_code == undefined ||
        jsonData[i].project_code == "" ||
        jsonData[i].project_code == null ||
        jsonData[i].employee_code == undefined ||
        jsonData[i].employee_code == "" ||
        jsonData[i].employee_code == null ||
        jsonData[i].client_time == undefined ||
        jsonData[i].client_time == "" ||
        jsonData[i].client_time == null ||
        jsonData[i].with_tracker == undefined ||
        jsonData[i].with_tracker == null
      ) {
        failedTasks.count++;
        failedTasks.data.push(jsonData[i]);
      } else {
        let flag = true;

        // for checking existing title in same project
        // const existTitle = await Tasks.findOne({
        //   title: { $regex: `^${jsonData[i].title}$`, $options: "i" },
        //   project_code: jsonData[i].project_code,
        // });
        // if (existTitle) {
        //   flag = false;
        //   if (!failedTasks.data.some((e) => e.title == jsonData[i].title)) {
        //     failedTasks.count++;
        //     failedTasks.data.push(jsonData[i]);
        //   }
        // }

        // for checking project_code exists or not
        await checkColumn(
          Project,
          "project_code",
          jsonData[i].project_code,
          "SUCCESS",
          "FAILED",
          ENUMS.VALIDATION_TYPE.EXISTS
        ).catch((err) => {
          flag = false;
          if (!failedTasks.data.some((e) => e.title == jsonData[i].title)) {
            failedTasks.count++;
            failedTasks.data.push(jsonData[i]);
          }
        });

        // for checking employee_code exists or not
        await checkColumn(
          Employee,
          "employee_code",
          jsonData[i].employee_code,
          "SUCCESS",
          "FAILED",
          ENUMS.VALIDATION_TYPE.EXISTS
        ).catch((err) => {
          flag = false;
          if (!failedTasks.data.some((e) => e.title == jsonData[i].title)) {
            failedTasks.count++;
            failedTasks.data.push(jsonData[i]);
          }
        });

        // for checking employee_code in project or not
        let data = await Employee_Project.findOne({
          employee_code: jsonData[i].employee_code,
          project_code: jsonData[i].project_code,
          is_deleted: false,
          is_disable: false,
        });

        if (!data) {
          flag = false;
          if (!failedTasks.data.some((e) => e.title == jsonData[i].title)) {
            failedTasks.count++;
            failedTasks.data.push(jsonData[i]);
          }
        }

        if (flag) {
          let newData = {
            title: jsonData[i].title,
            description: jsonData[i].description,
            project_code: jsonData[i].project_code,
            employee_code: jsonData[i].employee_code,
            client_time: jsonData[i].client_time,
            with_tracker: jsonData[i].with_tracker.toLowerCase(),
            due_date: jsonData[i].due_date,
            assigned_on: jsonData[i].assigned_on,
            created_by: auth_employee_code,
            created_date: moment().format(),
            status_history: [
              {
                status_from: null,
                status_to: ENUMS.TASK_STATUS.TODO,
                updated_by: auth_employee_code,
                updated_date: moment().format(),
              },
            ],
          };

          successTasks.count++;
          successTasks.data.push(newData);
        }
      }
    }

    if (successTasks.data.length) {
      await Tasks.create(successTasks.data);
    }

    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
      message: TASK_MESSAGE.TASK_SAVED,
      data: {
        failedTasks: failedTasks,
        successTasks: successTasks,
      },
      error: null,
    };
    return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* Export today's task which is in QA stage */
// -----Cron job------------------------
cron.schedule("0 18 * * *", async function () {
  try {
    var start = new Date();
    start.setHours(0, 0, 0, 0);

    var end = new Date();
    end.setHours(23, 59, 59, 999);

    var getTasks = await Tasks.find({
      is_deleted: false,
      status: ENUMS.TASK_STATUS.READY_TO_QA,
      status_history: {
        $elemMatch: {
          status_to: ENUMS.TASK_STATUS.READY_TO_QA,
          updated_date: {
            $gte: start,
            $lt: end,
          },
        },
      },
    }).select({
      _id: 1,
      title: 1,
      description: 1,
      project_code: 1,
      employee_code: 1,
      client_time: 1,
      with_tracker: 1,
      due_date: 1,
      assigned_on: 1,
    });

    if (getTasks.length) {
      getTasks = JSON.parse(JSON.stringify(getTasks));

      var worksheetColumns = [
        [
          "title",
          "description",
          "project_code",
          "employee_code",
          "client_time",
          "with_tracker",
          "due_date",
          "assigned_on",
          "_id",
        ],
      ];

      let newArray = [];
      getTasks.forEach((el) => {
        let newObj = {};
        worksheetColumns[0].forEach((e) => {
          if (el.hasOwnProperty(e)) {
            newObj[e] = el[e];
          }
        });
        newArray.push(newObj);
      });

      let newArrayForFiles = [];
      newArray.forEach((e) => {
        if (!newArrayForFiles.some((el) => el.project_code == e.project_code)) {
          newArrayForFiles.push({
            project_code: e.project_code,
            tasks: [e],
          });
        } else {
          newArrayForFiles.find((el) => {
            if (el.project_code == e.project_code) {
              el.tasks.push(e);
              return true;
            }
          });
        }
      });

      const folderCreate = path.resolve("public/images/" + "tasks");
      if (!fs.existsSync(folderCreate)) fs.mkdirSync(folderCreate);

      let newFiles = [];
      newArrayForFiles.forEach((element) => {
        var filePath =
          folderCreate +
          "/" +
          element.project_code +
          "_" +
          Date.now() +
          ".xlsx";

        var worksheetName = `Ready_To_QA_${element.project_code}`;
        var workbook = XLSX.utils.book_new();
        var worksheet = XLSX.utils.json_to_sheet(element.tasks, {
          origin: "A2",
          skipHeader: true,
        });
        XLSX.utils.sheet_add_aoa(worksheet, worksheetColumns);
        XLSX.utils.book_append_sheet(workbook, worksheet, worksheetName);
        XLSX.writeFile(workbook, path.resolve(filePath));
        newFiles.push(path.resolve(filePath));
      });

      let getProjectCodes = newArray.map((e) => e.project_code);
      let getAllProjects = await Project.aggregate([
        {
          $match: {
            project_code: { $in: getProjectCodes },
            is_deleted: false,
          },
        },
        {
          $lookup: {
            from: LEAD,
            let: { l_code: "$lead_code" },
            pipeline: [
              {
                $match: {
                  $expr: { $eq: ["$lead_code", "$$l_code"] },
                  is_deleted: false,
                },
              },
              {
                $project: {
                  _id: 0,
                  lead_assign: 1,
                },
              },
            ],
            as: "leads",
          },
        },
        {
          $unwind: {
            path: "$leads",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $set: {
            leads: "$leads.lead_assign",
          },
        },
        { $unwind: "$leads" },
        {
          $lookup: {
            from: EMPLOYEE,
            let: { l_code: "$leads" },
            pipeline: [
              {
                $match: {
                  $expr: { $eq: ["$_id", "$$l_code"] },
                  is_deleted: false,
                },
              },
              {
                $project: {
                  _id: 0,
                  email: 1,
                },
              },
            ],
            as: "employees",
          },
        },
        { $unwind: "$employees" },
        {
          $group: {
            _id: "$_id",
            project_code: { $first: "$project_code" },
            project_title: { $first: "$project_title" },
            lead_code: { $first: "$lead_code" },
            employees: { $push: "$employees" },
          },
        },
        {
          $addFields: {
            employees: "$employees.email",
          },
        },
      ]);

      for (let i = 0; i < newArrayForFiles.length; i++) {
        if (
          getAllProjects.some(
            (el) => el.project_code == newArrayForFiles[i].project_code
          )
        ) {
          let getEmployees = getAllProjects.find(
            (el) => el.project_code == newArrayForFiles[i].project_code
          );

          let filename = newFiles.find((e) =>
            e.includes(getEmployees.project_code)
          );

          await changeTaskStatusMailer(
            getEmployees.project_title,
            getEmployees.employees,
            filename
          );
        }
      }

      await Cron_Job_Logs.create({
        title: "Export Excel file cron running.",
        status: "Success",
        message: "Tasks found in ready to review",
        created_date: moment().format(),
      });

      console.log("Cron run successfully.");
    } else {
      await Cron_Job_Logs.create({
        title: "Export Excel file cron running.",
        status: "Success",
        message: "No tasks found in ready to review",
      });
      console.log("Cron has no data.");
    }
  } catch (error) {
    await Cron_Job_Logs.create({
      title: "Cron run with errors.",
      status: "Failed",
      message: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
      created_date: moment().format(),
    });
    console.log("Cron run with errors.");
  }
});

/* Read excel file and get all tasks for do it done. // METHOD: GET */
const getAllTasksForDone = async (req, res) => {
  try {
    const { filename } = req.params;
    let path = "public/images/tasks/" + filename + ".xlsx";

    if (!fs.existsSync(path)) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: null,
        error: TASK_MESSAGE.EXCEL_FILE_NOT_FOUND,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }

    var workbook = XLSX.readFile(path);
    var sheet_name_list = workbook.SheetNames;
    let jsonData = XLSX.utils.sheet_to_json(
      workbook.Sheets[sheet_name_list[0]]
    );

    if (jsonData.length) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_FOUND,
        data: jsonData,
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: null,
        error: TASK_MESSAGE.TASK_NOT_FOUND,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

// Make all tasks for do it done. // METHOD: POST // PARAMS: tasks:["task_id"] */
const makeTasksDone = async (req, res) => {
  try {
    const { employee_code: auth_employee_code } = req[AUTH_USER_DETAILS];
    const { tasks } = req.body;
    let result = await Tasks.updateMany(
      { _id: { $in: tasks } },
      {
        $set: {
          $push: {
            status_history: {
              status_from: ENUMS.TASK_STATUS.READY_TO_QA,
              status_to: ENUMS.TASK_STATUS.DONE,
              updated_by: auth_employee_code,
              updated_date: moment().format(),
            },
          },
          status: ENUMS.TASK_STATUS.DONE,
          updated_by: auth_employee_code,
          updated_date: moment().format(),
        },
      }
    );
    if (result) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_SAVED,
        data: null,
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: null,
        error: TASK_MESSAGE.TASK_NOT_SAVED,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* Change TASK STATUS // METHOD: PUT // PAYLOAD: employee_code, task_id, status_from, status_to */
const changeTaskStatus = async (req, res) => {
  try {
    const { employee_code, task_id, status_from, status_to } = req.body;
    const { employee_code: auth_employee_code, role } = req[AUTH_USER_DETAILS];

    if (
      status_to.toLowerCase() == ENUMS.TASK_STATUS.IN_PROGRESS.toLowerCase()
    ) {
      let prevTask = await Tasks.findOne({
        status: ENUMS.TASK_STATUS.IN_PROGRESS,
        employee_code: employee_code,
        is_deleted: false,
        is_disabled: false,
      });

      if (prevTask) {
        const responsePayload = {
          status: RESPONSE_PAYLOAD_STATUS_ERROR,
          message: null,
          data: null,
          error: TASK_MESSAGE.TASK_EXISTS,
        };
        return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
      }
    }

    let task_status = await Tasks.findByIdAndUpdate(
      task_id,
      {
        $push: {
          status_history: {
            status_from: status_from,
            status_to: status_to,
            updated_by: auth_employee_code,
            updated_date: moment().format(),
          },
        },
        status: status_to,
        updated_by: auth_employee_code,
        updated_date: moment().format(),
      },
      { new: true }
    );
    const comments = await Task_Comments.find({ task_id });

    if (task_status) {
      task_status = {
        ...task_status._doc,
        comments: comments,
        due_date: dateAndTimeFormat(task_status._doc.due_date, "Asia/Kolkata"),
        assigned_on: dateAndTimeFormat(
          task_status._doc.assigned_on,
          "Asia/Kolkata"
        ),
      };
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_SAVED,
        // data: { ...task_status._doc, comments },
        data: task_status,
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: null,
        error: TASK_MESSAGE.TASK_NOT_SAVED,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* UPDATE TASK // METHOD: PUT // PAYLOAD: employee_code, task_id, status_from, status_to */
const updateTask = async (req, res) => {
  try {
    const { employee_code: auth_employee_code } = req[AUTH_USER_DETAILS];
    const { task_id } = req.params;

    if (req.body.due_date) {
      req.body.due_date = momentTimezone
        .tz(new Date(req.body.due_date), "Asia/Kolkata")
        .format();
    }
    if (req.body.assigned_on) {
      req.body.assigned_on = momentTimezone
        .tz(new Date(req.body.assigned_on), "Asia/Kolkata")
        .format();
    }
    const updatedObj = {
      ...req.body,
      updated_by: auth_employee_code,
      updated_date: moment().format(),
    };

    let result = await Tasks.findByIdAndUpdate(task_id, updatedObj, {
      new: true,
    });

    if (result) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_SAVED,
        data: result,
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: null,
        error: TASK_MESSAGE.TASK_NOT_SAVED,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* DELETE TASK // METHOD: DELETE // PARAMS: task_id */
const deleteTask = async (req, res) => {
  try {
    const { employee_code: auth_employee_code } = req[AUTH_USER_DETAILS];
    const { task_id } = req.params;

    let result = await Tasks.findByIdAndUpdate(
      task_id,
      { is_deleted: true, deleted_by: auth_employee_code },
      {
        new: true,
      }
    );

    if (result) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_DELETED,
        data: null,
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: null,
        error: TASK_MESSAGE.TASK_NOT_DELETED,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* DELETE TASK HARD // METHOD: DELETE // PARAMS: task_id */
const deleteTaskHard = async (req, res) => {
  try {
    const { task_id } = req.params;

    let result = await Tasks.findByIdAndDelete(task_id);

    if (result) {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TASK_MESSAGE.TASK_DELETED,
        data: null,
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_ERROR,
        message: null,
        data: null,
        error: TASK_MESSAGE.TASK_NOT_DELETED,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

/* LIST TEAM TASK // METHOD: GET */
const teamTaskList = async (req, res) => {
  try {
    const { employee_code } = req[AUTH_USER_DETAILS];

    const teamManagement = await Team_managment.findOne({
      team_leader: employee_code,
    });

    if (teamManagement) {
      const teamMembers = teamManagement.team_member;
      const tasks = await Tasks.aggregate([
        {
          $match: { employee_code: { $in: teamMembers } },
        },
        {
          $group: {
            _id: "$employee_code",
            task_details: { $push: "$$ROOT" },
          },
        },
        {
          $project: {
            _id: 0,
            employee_code: "$_id",
            task_details: 1,
          },
        },
      ]);

      const teamMemberTasksMap = new Map();
      tasks.forEach((task) => {
        teamMemberTasksMap.set(task.employee_code, task.task_details);
      });

      const teamMembersWithTasks = teamMembers.map((member) => {
        const tasks = teamMemberTasksMap.get(member);
        return {
          employee_code: member,
          task_details: tasks || "---",
        };
      });

      if (teamMembersWithTasks.length > 0) {
        const responsePayload = {
          status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
          message: TEAM_MESSAGE.TEAM_TASK_FOUND,
          data: teamMembersWithTasks,
          error: null,
        };
        return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
      } else {
        const responsePayload = {
          status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
          message: TEAM_MESSAGE.TEAM_TASK_NOT_FOUND,
          data: [],
          error: null,
        };
        return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
      }
    } else {
      const responsePayload = {
        status: RESPONSE_PAYLOAD_STATUS_SUCCESS,
        message: TEAM_MESSAGE.TEAM_NOT_FOUND,
        data: {},
        error: null,
      };
      return res.status(RESPONSE_STATUS_CODE_OK).json(responsePayload);
    }
  } catch (error) {
    const responsePayload = {
      status: RESPONSE_PAYLOAD_STATUS_ERROR,
      message: null,
      data: null,
      error: RESPONSE_STATUS_MESSAGE_INTERNAL_SERVER_ERROR,
    };
    return res
      .status(RESPONSE_STATUS_CODE_INTERNAL_SERVER_ERROR)
      .json(responsePayload);
  }
};

module.exports = {
  addTask,
  listTasks,
  listAllTasks,
  listTasksById,
  updateTask,
  changeTaskStatus,
  deleteTask,
  deleteTaskHard,
  addTaskByExcelFile,
  getAllTasksForDone,
  makeTasksDone,
  allEmployeeTaskInfotracker,
  teamTaskList,
  listTaskHour,
};
